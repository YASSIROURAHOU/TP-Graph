public class Main {
    public static void main(String[] args) {
        Graph graph = new Graph();

        // Créer les sommets
        Vertex A = new Vertex("A");
        Vertex B = new Vertex("B");
        Vertex C = new Vertex("C");
        Vertex D = new Vertex("D");

        // Ajouter les sommets au graphe
        graph.addVertex(A);
        graph.addVertex(B);
        graph.addVertex(C);
        graph.addVertex(D);

        // Créer et ajouter les arêtes au graphe
        graph.addEdge(A, B);
        graph.addEdge(A, B);  // Même arête (A, B) ajoutée deux fois
        graph.addEdge(A, C);
        graph.addEdge(B, C);
        graph.addEdge(B, C);
        graph.addEdge(B, C);
        graph.addEdge(B, D);

        // Afficher tous les sommets et arêtes
        System.out.println(graph);
    }
}