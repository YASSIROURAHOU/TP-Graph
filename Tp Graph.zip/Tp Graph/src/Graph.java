import java.util.HashSet;
import java.util.Set;

public class Graph {
    private Set<Vertex> vertices;
    private Set<Edge> edges;

    public Graph() {
        vertices = new HashSet<>();
        edges = new HashSet<>();
    }

    public void addVertex(Vertex v) {
        vertices.add(v);
    }

    public void addEdge(Vertex from, Vertex to) {
        Edge edge = new Edge(from, to);
        edges.add(edge);
    }

    public Set<Vertex> getVertices() {
        return vertices;
    }

    public Set<Edge> getEdges() {
        return edges;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("Vertices: \n");
        for (Vertex v : vertices) {
            sb.append(v).append("\n");
        }
        sb.append("Edges: \n");
        for (Edge e : edges) {
            sb.append(e).append("\n");
        }
        return sb.toString();
    }
}